using static System.Console;
class HelloClass
{
   static void Main()
   {
      ShowWelcomeMessage();
      WriteLine("Hello");
   }
   private static void ShowWelcomeMessage()
   {
      WriteLine("Welcome.");
      WriteLine("Have fun!");
      WriteLine("Enjoy the program!");
   }
}
